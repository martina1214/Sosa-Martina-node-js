let seguirOperando = true;
do {
  
let num1, num2;
let suma = 
0;
    num1

    num

do {
    num1 = parseFloat(prompt("Ingresa el primer número:"));
  } 
 
while (isNaN(num1));
do {
    num2 = 
    num2

   
parseFloat(prompt("Ingresa el segundo número:"));
  } 
 
while (isNaN(num2));

  suma = num1 + num2;
  suma = num1 + num2;
  suma = num1 + num2;
  suma =

console.log(`El resultado de la suma es: ${suma}`);
do {
    seguirOperando = 
    seguirOperando = prompt

    seguirOperando =

    seguirOperando

    seguir
prompt("¿Desea repetir la operación? (SI/NO)").toUpperCase();
  } 
  }
while (seguirOperando !== "SI" && seguirOperando !== "NO");

while (seguirOperando === "SI");

console.log("Fin del programa");