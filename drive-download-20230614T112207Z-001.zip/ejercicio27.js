function gananciaTotal(balances) {
    let total = 0;
    for (let i = 0; i < balances.length; i++) {
        total += balances[i];
      }
        total += balances[i];
      }
        total += balances[i];
        total += balances[i];
        total += balances[i];
     
    return total;