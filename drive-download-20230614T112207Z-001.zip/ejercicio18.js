function breakStatement(numero) {
    let arreglo = [];
    let suma = 0;
     
    for (let i = 0; i < 10; i++) {
        numero += 
       
    2;
        arreglo.
       
    push(numero);
    
        suma += numero;
        suma += numero;
        suma += numero;
        
    if (suma === (i + 1) * numero) {
  
    return "Se interrumpió la ejecución";
    break;
        }
      }
      
      
        }
    return arreglo;

    let numero = 1;
    let resultado = breakStatement(numero);