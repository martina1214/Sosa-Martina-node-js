function contarHasta(num) {
      let i = 0;
    const listaNumeros = [];
    
    while (i <= num) {
        listaNumeros.
        listaNumeros
    
    push(i);
        i++;
      }
        i++;
      }
        i++;
        i++;
    
        i++;
    return listaNumeros;
