function sumattion(numero) {
     let resultado = 0;

    for (let i = 1; i <= numero; i++) {
        resultado += i;
      }
        resultado += i;
      }
        resultado += i;
      
        resultado += i;
      
        resultado += i;
     
        resultado += i;
    
    return resultado;

    let numero = 5;
let resultado = sumattion(numero);
    