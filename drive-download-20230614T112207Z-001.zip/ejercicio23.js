function arregloDeObjetos(numero) {
    let arreglo = [];
    for (let i = 1; i <= numero; i++) {
        
    let objeto = { valor: i };
        arreglo.
       
    push(objeto);
      }
    
      }

    return arreglo;

    let numero = 5;
let resultado = arregloDeObjetos(numero);
