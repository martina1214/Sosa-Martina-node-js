function rango(comienzo, final, sumador) {
    let numeros = [];
      
    for (let i = comienzo; i <= final; i += sumador) {
        numeros.
       
    push(i);
      }
      
      
      }
      
    
    return numeros;
      
    let comienzo = 1;
let final = 10;
let sumador = 2;
let resultado = rango(comienzo, final, sumador);
  