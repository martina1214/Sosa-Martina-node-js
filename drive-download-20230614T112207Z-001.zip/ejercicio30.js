let total = 0;
let input = parseInt(prompt("Teclea un número:"));

while(input !== 0) {
  total += input;
  input = 

  total += input;
  input =

  total += input;
  input

  total += input; 
  total += input;
 
parseInt(prompt("Teclea otro número o 0 para salir:"));
}

console.log("La suma total es: " + total);