let letra;
do {
  letra = prompt("Ingresa la letra F en mayúscula:");
} while (letra !== "F");

console.log("¡Lo lograste!");