function nuevoArreglo(numero) {
    let arreglo = [];
     
    for (let i = 0; i < numero; i++) {
        arreglo.
       
    push(i);
      }
      
      
      }
      
    return arreglo;

    let numero = 5;
let resultado = nuevoArreglo(numero);