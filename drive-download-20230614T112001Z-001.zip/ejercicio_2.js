//tp1
console.log("Hola Mundo");

//tp2
var num1= 7;
var num2= 5;
5 * num1;
num3= num2 + num1;
console.log(num3);
